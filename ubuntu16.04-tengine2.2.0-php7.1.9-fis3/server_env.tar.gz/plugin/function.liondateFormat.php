<?php
/**
*           File:  function.liondateFormat.php
 *         Author:  lion(lion.888@gmail.com)
 *       Modified:  2015-8-18 23:16:52
 *    Description: 对过去时的日期进行格式化
 * * @example
 *       {liondateFormat date="2015-08-18 15:10:21"}
 * @param $params
 * @param $smarty
 */

function smarty_function_liondateFormat($params, &$smarty) {
    $time = strtotime($params["date"]);
    $sentTime = time()-$time;
    if($sentTime<0){
        return "时间错误";
    }else if( $sentTime<60){
        return ($sentTime)."秒前";
    }else if ($sentTime<3600){
        return floor($sentTime/60)."分钟前";
    }else if($sentTime<86400){
        return floor($sentTime/3600)."小时前";
    }else{
        if(floor($sentTime/86400)<11){
            return floor($sentTime/86400)."天前";
        }else{
            return date('Y-m-d',$time);
        }
    }
}


