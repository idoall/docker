<?php

// fis.baidu.com

if (!defined('WWW_ROOT')) define ('WWW_ROOT', dirname(__FILE__) . '/../');
if (!defined('ROOT')) define ('ROOT', dirname(__FILE__) . '/');
