
require('fis3-smarty')(fis);
fis.set('namespace', 'common');
fis.set('project.ignore', ['*.bak']); 

/**
 * 开发阶段不压缩
 * fis3 server install server-env
 * 使用方法：
 * fis3 release 压缩
 * fis3 release dev 不压缩
 */
// fis.media('dev').match('*.js', {
//   optimizer: null  //不压缩
// });

fis.match('/widget/{*.{js,css},**/*.{js,css}}', {
  isMod: true
});
fis.match('/static/js/jquery/{*,**/*}.js', {
  useHash:false
});
//异步加载的style文件，不做hash
fis.match('/static/js/jquery/{*,**/*}.css', {
  useHash:false
});
//异步加载的template文件，不做hash
fis.match('/static/js/template.js', {
  useHash:false
});

fis.match('/static/js/{*,**/*,**/*/*,**/*/*/*}.{js,css}', {
    useHash:false,
    optimizer: null
});
fis.match('/widget/{*,**/*}.{js,css}', {
    useHash:false,
    optimizer: null
});

// //针对核心通用模块打包
// fis.match('{static/css/*.css,widget/common/**.css}', {
//   packTo: 'static/pkg/common.css'
// });
// fis.match('{static/mod.js,static/lazyload/lazyload_min.js,static/js/jquery/jquery.mousewheel.min.js,static/js/*.js,static/js/jquery/jquery_jcryption_3_1_0.js,static/js/jquery/blockUI/jquery_blockUI.js,widget/common/**.js}', {
//   packTo: 'static/pkg/common.js'
// });
// fis.match('widget/pager/**.css', {
//   packTo: 'static/pkg/pager.css'
// });
// fis.match('widget/search/**.css', {
//   packTo: 'static/pkg/search.css'
// });
// fis.match('widget/search/**.js', {
//   packTo: 'static/pkg/search.js'
// });
// //控制合并时的顺序，值越小越在前面。配合 packTo 一起使用
// fis.match('static/mod.js', {
//   packOrder: -100
// });


//--------------------------------------以下为QA Rlease的配置
fis.media('qa').match('*', {
    url:'/static/${namespace}$0',
    release: 'web/${static}/${namespace}/$0' 
});
fis.media('qa').match('${namespace}-map.json', {
    release: '/config/fis/$0'
});
fis.media('qa').match('/{plugin,smarty.conf,domain.conf,**.php}', {
    release: '$0'
});
fis.media('qa').match('favicon.ico', {
    release: 'web/$0',
    useHash: false
});
fis.media('qa').match('*.tpl', {
  preprocessor: fis.plugin('extlang'),
  postprocessor: fis.plugin('require-async'),
  optimizer: [
    fis.plugin('smarty-xss'),
    fis.plugin('html-compress')
  ],
  useMap: true,
  release: '/${template}/${namespace}/$0'
});
fis.media('qa').match('/(widget/**.tpl)', {
  url: '${namespace}/$1',
  useMap: true,
});
fis.media('qa').match('*.{js,css,less}', {
  useHash: true
});
fis.media('qa').match('*.js', {
  optimizer: fis.plugin('uglify-js')
});
fis.media('qa').match('::image', {
  useHash: true
});
fis.media('qa').match('*.{tpl,js}', {
  useSameNameRequire: true
});
fis.media('qa').match('/page/**.tpl', {
  extras: {
    isPage: true
  }
});
fis.media('qa').match('::package', {
  spriter: fis.plugin('csssprites')
})

// 对 CSS 进行图片合并
fis.media('qa').match('*.css', {
  // 给匹配到的文件分配属性 `useSprite`
  useSprite: true
});
fis.media('qa').match('/widget/{*.{js,css},**/*.{js,css}}', {
  isMod: true
});
fis.media('qa').match('/static/js/jquery/{*,**/*}.js', {
  useHash:false
});
//异步加载的style文件，不做hash
fis.media('qa').match('/static/js/jquery/{*,**/*}.css', {
  useHash:false
});
//异步加载的template文件，不做hash
fis.media('qa').match('/static/js/template.js', {
  useHash:false
});

//针对核心通用模块打包
fis.media('qa').match('{static/css/*.css,widget/common/**.css}', {
  packTo: 'static/pkg/common.css'
});
fis.media('qa').match('{static/mod.js,static/lazyload/lazyload_min.js,static/js/jquery/jquery.mousewheel.min.js,static/js/*.js,static/js/jquery/jquery_jcryption_3_1_0.js,static/js/jquery/blockUI/jquery_blockUI.js,widget/common/**.js}', {
  packTo: 'static/pkg/common.js'
});
fis.media('qa').match('widget/pager/**.css', {
  packTo: 'static/pkg/pager.css'
});
fis.media('qa').match('widget/search/**.css', {
  packTo: 'static/pkg/search.css'
});
fis.media('qa').match('widget/search/**.js', {
  packTo: 'static/pkg/search.js'
});
//控制合并时的顺序，值越小越在前面。配合 packTo 一起使用
fis.media('qa').match('static/mod.js', {
  packOrder: -100
});


fis.media('qa').match('*', {
  deploy: fis.plugin('http-push', {
    exclude : /.*\.(?:svn|cvs|tar|rar|psd|bak).*/,
    receiver: 'http://127.0.0.1/receiver.php',
    to: '/Users/mator/Desktop/tsy-web' // 注意这个是指的是测试机器的路径，而非本地机器
  })
});
